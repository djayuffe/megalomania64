; --------------------------------------------------------------------------
; Raster interrupt engine.
;  * Stage 0 fires on line IRQ_LINE once per frame: bumps `vblank`, samples
;    joystick port 2 (before the KERNAL keyboard scan can disturb $DC00),
;    advances SID music/SFX, then chains into the KERNAL IRQ ($EA31) so the
;    keyboard buffer and jiffy clock keep working.
;  * Stages 1..BAR_COUNT only run while the title screen is up: each one
;    paints one raster bar (border + background) and arms the next line.
;    These exit through $EA81 (register restore + RTI only).
; The CIA timer IRQ is switched off so exactly one IRQ per frame is taken.
; --------------------------------------------------------------------------
irq_install:
 sei
 lda #$36
 sta $01                    ; BASIC ROM out: RAM at $A000-$BFFF (sample bank); KERNAL and I/O stay
 lda #$7f
 sta $dc0d                   ; CIA1: no interrupt sources
 sta $dd0d                   ; CIA2: no NMI sources
 lda $dc0d                   ; acknowledge anything pending
 lda $dd0d
 lda #<irq_handler
 sta $0314
 lda #>irq_handler
 sta $0315
 lda #IRQ_LINE
 sta $d012
 sta irq_line
 lda $d011
 and #$7f                    ; raster compare bit 8 = 0
 sta $d011
 lda #$ff
 sta $d019                   ; clear VIC flags
 jsr sample_init             ; NMI vector for the sample player
 lda #$01
 sta $d01a                   ; raster IRQ only
 lda #0
 sta irq_stage
 sta title_active
 cli
 rts

irq_handler:
 lda $d019
 and #1
 beq irq_not_ours
 lda #$ff
 sta $d019                   ; acknowledge raster IRQ
 lda irq_stage
 bne irq_bar
 inc vblank
 lda #$ff
 sta $dc00                   ; no keyboard column selected: pins show only the joystick
 lda $dc00
 and #31
 sta joy_raw
 jsr sound_tick              ; SFX gate timer + music sequencer
 jsr fx_tick                 ; border flash, screen shake, sprite colour pulse
 lda ic_active
 beq irq_native_bars
 lda ic_visible_mode
 cmp #3
 beq irq_credit_top
 cmp #2
 bne irq_not_ours
 lda #$18
 sta $d016
 lda #210                    ; 160 pixels of art, then hires story text
 sta $d012
 lda #18
 sta irq_stage
 jmp irq_not_ours
irq_credit_top:
 lda $dd00
 and #$fc
 sta $dd00
 lda #$38
 sta $d018
 lda cr_y
 ora #$18
 sta $d011
 lda #208                    ; allow for a 40-cycle badline before the logo split
 sta $d012
 lda #19
 sta irq_stage
 jmp irq_not_ours
irq_native_bars:
 lda title_active
 beq irq_not_ours
 lda vblank                  ; title: arm the wobbling raster-bar stack
 and #31
 tax
 lda bar_wave,x
 sta irq_line
 sta $d012
 lda #1
 sta irq_stage
irq_not_ours:
 jmp $ea31                   ; KERNAL: keyboard scan, jiffy clock, pops regs, RTI

irq_bar:
 ldx irq_stage               ; 1..BAR_COUNT paint, BAR_COUNT+1 restores
 cpx #19
 beq irq_credit_logo
 cpx #18
 beq irq_scene_split
 cpx #BAR_COUNT+1
 bcs irq_bar_last
 lda bar_color-1,x
 sta $d020
 sta $d021
 inx
 stx irq_stage
 lda irq_line
 clc
 adc #BAR_SPACING
 sta irq_line
 sta $d012
 jmp $ea81
irq_credit_logo:
 lda $dd00
 and #$fc
 ldx cr_y
 cpx #4
 bcc irq_logo_bank3
 ora #2
 tay
 ldx #$48
 bne irq_logo_wait
irq_logo_bank3:
 tay
 ldx #$28
irq_logo_wait:
 lda $d012
 cmp #210
 bcc irq_logo_wait
 sty $dd00
 stx $d018
 lda #$3b
 sta $d011
 jmp irq_scene_split
irq_scene_split:
 lda #8
 sta $d016
 lda #IRQ_LINE
 sta $d012
 lda #0
 sta irq_stage
 jmp $ea81

irq_bar_last:
 lda #6
 ldy title_bmp
 beq ib_frame
 lda #0                      ; intro picture: black frame and background
ib_frame:
 sta $d020                   ; back to the resting frame colour
 sta $d021
 lda #IRQ_LINE
 sta $d012
 sta irq_line
 lda #0
 sta irq_stage
 jmp $ea81

; Sleep until the next vertical blank. Needs interrupts enabled.
wait_frame:
 lda vblank
wf_spin:
 cmp vblank
 beq wf_spin
 rts
